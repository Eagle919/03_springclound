package com.atguigu.bean

/**
  *
  * @param timestamp 时间戳
  * @param area      大区
  * @param city      城市
  * @param userid    用户
  * @param adid      广告
  */
case class AdsLog(
                   timestamp: Long,
                   area: String,
                   city: String,
                   userid: String,
                   adid: String)
