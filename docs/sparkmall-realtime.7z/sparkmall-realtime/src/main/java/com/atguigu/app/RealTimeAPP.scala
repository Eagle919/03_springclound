package com.atguigu.app

import com.atguigu.bean.AdsLog
import com.atguigu.handler.{BlackListHandler, DateAreaCityAdsCountHandler}
import com.atguigu.utils.MyKafkaUtil
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.spark.SparkConf
import org.apache.spark.streaming.dstream.{DStream, InputDStream}
import org.apache.spark.streaming.{Seconds, StreamingContext}

object RealTimeAPP {

  def main(args: Array[String]): Unit = {

    //1.创建SparkConf
    val sparkConf: SparkConf = new SparkConf().setAppName("RealTimeAPP").setMaster("local[*]")

    //2.创建StreamingContext
    val ssc = new StreamingContext(sparkConf, Seconds(3))

    ssc.sparkContext.setCheckpointDir("./ck1")

    //3.指定消费的主题
    val topic = "ads_log"

    //4.读取Kafka数据
    val kafkaDStream: InputDStream[ConsumerRecord[String, String]] = MyKafkaUtil.getKafkaStream(ssc, Array(topic))

    //5.将ConsumerRecord转换为自定义的JavaBean
    val adsLogDStream: DStream[AdsLog] = kafkaDStream.map(record => {

      //取出其中的值
      val splits: Array[String] = record.value().split(" ")

      //封装为样例类对象
      AdsLog(splits(0).toLong, splits(1), splits(2), splits(3), splits(4))
    })

    //6.查询黑名单进行数据过滤
    val filterdDStream: DStream[AdsLog] = BlackListHandler.filterDataByBlackList(ssc.sparkContext, adsLogDStream)

    //统计每天每个地区每个城市每个广告的点击次数
    val dateAreaCityAdsToCount: DStream[(String, Long)] = DateAreaCityAdsCountHandler.getDateAreaCityAdsCount(filterdDStream)

    //将每天每个地区每个城市每个广告的点击次数写入Redis
    DateAreaCityAdsCountHandler.saveDataToRedis(dateAreaCityAdsToCount)

    //7.校验数据是否需要加入黑名单，如果超过100次，则加入黑名单
    BlackListHandler.checkUserToBlackList(filterdDStream)

    //6.测试数据
    adsLogDStream.print()

    //启动
    ssc.start()
    ssc.awaitTermination()


  }

}
