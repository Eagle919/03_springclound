package com

import java.text.DecimalFormat

object atguiguTest {

  def main(args: Array[String]): Unit = {

    println(Math.round(22.toDouble * 1000 / 33) / 10D)

  }

}
