package com.atguigu.app

import java.util.{Properties, UUID}

import com.alibaba.fastjson.{JSON, JSONObject}
import com.atguigu.datamode.UserVisitAction
import com.atguigu.handler.SingleJumpRatioHandler
import com.atguigu.utils.{JdbcUtil, PropertiesUtil}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object SingleJumpRatioApp {

  def main(args: Array[String]): Unit = {

    //1.创建SparkSession
    val spark: SparkSession = SparkSession.builder()
      .master("local[*]")
      .appName("SingleJumpRatioApp")
      .enableHiveSupport()
      .getOrCreate()

    //导入隐式转换
    import spark.implicits._

    //2.读取配置文件
    val properties: Properties = PropertiesUtil.load("conditions.properties")
    val condition: String = properties.getProperty("condition.params.json")

    //获取JSON对象
    val conditionObj: JSONObject = JSON.parseObject(condition)

    //获取跳转目标页面
    val targetPageFlow: String = conditionObj.getString("targetPageFlow")

    //1-7
    val targetPageFlowArray: Array[String] = targetPageFlow.split(",")

    //3.准备单页所需的过滤条件:1-6
    val singlePageArray: Array[String] = targetPageFlowArray.dropRight(1)

    //4.准备单跳所需的过滤条件(1-6).zip(2-7)=>(1-2,2-3...)
    val toPageArray: Array[String] = targetPageFlowArray.drop(1)
    val singleJumpPageArray: Array[String] = singlePageArray.zip(toPageArray).map {
      case (from, to) =>
        s"$from-$to"
    }

    //5.读取Hive数据
    val userVisitActionRDD: RDD[UserVisitAction] = spark.sql("select * from user_visit_action").as[UserVisitAction].rdd

    userVisitActionRDD.cache()

    //6.过滤单页数据并计数
    val singlePageCount: RDD[(String, Long)] = SingleJumpRatioHandler.getSinglePageCount(userVisitActionRDD, singlePageArray)

    //7.过滤单跳数据并计数
    val singleJumpPageAndCount: RDD[(String, Long)] = SingleJumpRatioHandler.getSingleJumpCount(userVisitActionRDD, singleJumpPageArray)

    val taskId: String = UUID.randomUUID().toString

    //8.将数据拉取到Driver端处理
    val singlePageMap: Map[String, Long] = singlePageCount.collect().toMap
    val singleJumpPageAndCountArray: Array[(String, Long)] = singleJumpPageAndCount.collect()

    //9.计算跳转率
    val result: Array[Array[Any]] = singleJumpPageAndCountArray.map { case (singleJump, count) =>

      //计算跳转率
      val ratio: Double = count.toDouble / singlePageMap.getOrElse(singleJump.split("-")(0), 1L)

      Array(taskId, singleJump, ratio)
    }

    //10.写入MySQL
    JdbcUtil.executeBatchUpdate("insert into jump_page_ratio values(?,?,?)", result)

    //11.断开连接
    spark.close()

  }

}
