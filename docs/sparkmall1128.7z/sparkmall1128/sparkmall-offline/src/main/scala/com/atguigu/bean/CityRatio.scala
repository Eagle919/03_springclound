package com.atguigu.bean

case class CityRatio(cityName: String, ratio: Double) {

  override def toString: String = s"$cityName:$ratio%"
}
