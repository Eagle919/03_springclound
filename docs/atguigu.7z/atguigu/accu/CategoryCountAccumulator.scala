package com.atguigu.accu

import org.apache.spark.util.AccumulatorV2

import scala.collection.mutable

class CategoryCountAccumulator extends AccumulatorV2[String, mutable.HashMap[String, Long]] {

  private var categoryCount = new mutable.HashMap[String, Long]()

  //判空
  override def isZero: Boolean = categoryCount.isEmpty

  //拷贝
  override def copy(): AccumulatorV2[String, mutable.HashMap[String, Long]] = {

    val accumulator = new CategoryCountAccumulator

    accumulator.value ++= categoryCount

    accumulator
  }

  //重置
  override def reset(): Unit = categoryCount.clear()

  //区内聚合
  override def add(v: String): Unit = {
    categoryCount(v) = categoryCount.getOrElse(v, 0L) + 1L
  }

  //区间聚合
  override def merge(other: AccumulatorV2[String, mutable.HashMap[String, Long]]): Unit = {

    val otherCategoryCountMap: mutable.HashMap[String, Long] = other.value

    //将other数据合并至当前数据
    otherCategoryCountMap.foreach { case (category, count) =>
      this.categoryCount(category) = categoryCount.getOrElse(category, 0L) + count
    }
  }

  //返回值
  override def value: mutable.HashMap[String, Long] = categoryCount
}
