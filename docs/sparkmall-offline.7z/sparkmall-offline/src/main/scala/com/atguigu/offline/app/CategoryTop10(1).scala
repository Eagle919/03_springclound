package com.atguigu.offline.app

import java.util.{Properties, UUID}

import com.alibaba.fastjson.{JSON, JSONObject}
import com.atguigu.datamode.UserVisitAction
import com.atguigu.offline.accu.CategoryCountAccumulator
import com.atguigu.offline.handler.CategoryTop10Handler
import com.atguigu.utils.{JdbcUtil, PropertiesUtil}
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

import scala.collection.mutable

object CategoryTop10 {

  def main(args: Array[String]): Unit = {

    //1.创建SparkConf
    val sparkConf: SparkConf = new SparkConf().setMaster("local[*]").setAppName("CategoryTop10")

    //2.创建SparkSession
    val spark: SparkSession = SparkSession.builder()
      .master("local[*]")
      .appName("CategoryTop10")
      .enableHiveSupport()
      .getOrCreate()

    //3.获取文件中的过滤条件
    val conditionPro: Properties = PropertiesUtil.load("conditions.properties")
    val conditionJson: String = conditionPro.getProperty("condition.params.json")

    //4.将JSON转换为对象
    val conditionObj: JSONObject = JSON.parseObject(conditionJson)

    //5.读取Hive数据并进行过滤
    val userVisitActionRDD: RDD[UserVisitAction] = CategoryTop10Handler.readAndFilterData(conditionObj, spark)

    //6.创建累加器
    val accumulator = new CategoryCountAccumulator

    //7.注册累加器
    spark.sparkContext.register(accumulator, "categoryCount")

    //8.运用累加器求三种数据的次数（点击，下单，支付）
    userVisitActionRDD.foreach(userVisitAction => {

      //判断是否是点击数据
      if (userVisitAction.click_category_id != -1) {
        accumulator.add(s"click_${userVisitAction.click_category_id}")

        //如果不是点击数据，则判断是否是订单数据
      } else if (userVisitAction.order_category_ids != null) {

        //切分订单ID
        userVisitAction.order_category_ids.split(",").foreach(order_id =>
          accumulator.add(s"order_$order_id")
        )
        //如果还不是订单数据，则判断是否为支付数据
      } else if (userVisitAction.pay_category_ids != null) {

        //切分支付ID
        userVisitAction.pay_category_ids.split(",").foreach(pay_id =>
          accumulator.add(s"pay_$pay_id")
        )
      }
    })

    //9.获取累计器中的值(order_4,200)
    val categoryCountMap: mutable.HashMap[String, Long] = accumulator.value

    categoryCountMap.foreach(println)

    //10.按照品类ID进行分组(4,Map[(order_4,200),(click_4,200),(pay_4,200)])
    val categoryCountMapGroup: Map[String, mutable.HashMap[String, Long]] = categoryCountMap.groupBy(_._1.split("_")(1))

    //11.排序
    val result: List[(String, mutable.HashMap[String, Long])] = categoryCountMapGroup.toList.sortWith { case (c1, c2) =>

      //获取两个比较对象的数据信息
      val category1: String = c1._1
      val category1Count: mutable.HashMap[String, Long] = c1._2

      val category2: String = c2._1
      val category2Count: mutable.HashMap[String, Long] = c2._2

      //比较，先比较点击次数
      if (category1Count.getOrElse(s"click_$category1", 0L) > category2Count.getOrElse(s"click_$category2", 0L)) {
        true
        //如果点击次数相同，则比较订单次数
      } else if (category1Count.getOrElse(s"click_$category1", 0L) == category2Count.getOrElse(s"click_$category2", 0L)) {

        //判断订单次数
        if (category1Count.getOrElse(s"order_$category1", 0L) > category2Count.getOrElse(s"order_$category2", 0L)) {
          true

          //订单次数依然相同
        } else if (category1Count.getOrElse(s"order_$category1", 0L) == category2Count.getOrElse(s"order_$category2", 0L)) {

          //比较支付次数
          category1Count.getOrElse(s"pay_$category1", 0L) > category2Count.getOrElse(s"pay_$category2", 0L)
        } else {

          //订单次数小
          false
        }
      } else {

        //点击次数小
        false
      }
    }.take(10)

    //12.将排序后的结果数据进行结构调整，使每一行成为一个Array
    val taskId: String = UUID.randomUUID().toString

    val categoryCountTop10Array: List[Array[Any]] = result.map { case (category, categoryCount) =>
      Array(taskId, category, categoryCount.getOrElse(s"click_$category", 0L), categoryCount.getOrElse(s"order_$category", 0L), categoryCount.getOrElse(s"pay_$category", 0L))
    }

    //13.插入MySQL
    JdbcUtil.executeBatchUpdate("insert into category_top10 values(?,?,?,?,?)", categoryCountTop10Array)

    //14.关闭连接
    spark.close()

  }

}
