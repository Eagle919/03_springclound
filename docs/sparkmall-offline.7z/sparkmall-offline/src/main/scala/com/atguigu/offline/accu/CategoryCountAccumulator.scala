package com.atguigu.offline.accu

import org.apache.spark.util.AccumulatorV2

import scala.collection.mutable

class CategoryCountAccumulator extends AccumulatorV2[String, mutable.HashMap[String, Long]] {

  private var categoryCount = new mutable.HashMap[String, Long]()

  //判空
  override def isZero: Boolean = categoryCount.isEmpty

  //拷贝
  override def copy(): AccumulatorV2[String, mutable.HashMap[String, Long]] = {

    val accumulator = new CategoryCountAccumulator

    accumulator.value ++= categoryCount

    accumulator
  }

  //重置
  override def reset(): Unit = categoryCount.clear()

  //区内聚合
  override def add(v: String): Unit = {
    categoryCount(v) = categoryCount.getOrElse(v, 0L) + 1L
  }

  //区间聚合
  override def merge(other: AccumulatorV2[String, mutable.HashMap[String, Long]]): Unit = {

    println("*****")

    val value1: mutable.HashMap[String, Long] = other.value
    value1.foreach(println)

    //将其他的累计器中的值累加到当前累加器
    val stringToLong: mutable.HashMap[String, Long] = categoryCount.foldLeft(other.value) { case (otherMap, (category, count)) =>

      otherMap(category) = count + otherMap.getOrElse(category, 0L)

      otherMap
    }

    categoryCount = stringToLong
  }

  //返回值
  override def value: mutable.HashMap[String, Long] = categoryCount
}
