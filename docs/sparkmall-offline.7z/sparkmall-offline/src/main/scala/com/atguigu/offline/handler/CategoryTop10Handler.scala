package com.atguigu.offline.handler

import com.alibaba.fastjson.JSONObject
import com.atguigu.datamode.UserVisitAction
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

object CategoryTop10Handler {

  /**
    * 读取Hive数据并按照条件进行过滤
    *
    * @param conditionObj 过滤条件
    * @param spark        SparkSession
    * @return
    */
  def readAndFilterData(conditionObj: JSONObject, spark: SparkSession): RDD[UserVisitAction] = {

    //1.导入隐式转换
    import spark.implicits._

    //2.获取过滤参数
    val startDate: String = conditionObj.getString("startDate")
    val endDate: String = conditionObj.getString("endDate")
    val startAge: String = conditionObj.getString("startAge")
    val endAge: String = conditionObj.getString("endAge")

    //3.构建SQL语句
    val sql = new StringBuilder("select v.* from user_visit_action v join user_info u on v.user_id=u.user_id where 1=1")

    //4.判断过滤参数并追加条件
    if (startDate != null) {
      sql.append(s" and date>='$startDate'")
    }
    if (endDate != null) {
      sql.append(s" and date<='$endDate'")
    }
    if (startAge != null) {
      sql.append(s" and age>=$startAge")
    }
    if (endAge != null) {
      sql.append(s" and age<=$endAge")
    }

    println(sql.toString())

    //5.执行查询
    val df: DataFrame = spark.sql(sql.toString())

    //7.转换为RDD进行输出
    val userVisitActionRDD: RDD[UserVisitAction] = df.as[UserVisitAction].rdd

    userVisitActionRDD
  }

  def main(args: Array[String]): Unit = {


  }

  def addStr(s1: String, s2: String) {

    val s3 = new String(s1 + s2)

    s3

  }


}
